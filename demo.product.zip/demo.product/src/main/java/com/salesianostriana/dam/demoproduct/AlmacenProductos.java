package com.salesianostriana.dam.demoproduct;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Repository;

import jakarta.annotation.PostConstruct;



@Repository
public class AlmacenProductos {
	
	private List<Producto> lista;
	
	@PostConstruct
	public void init() {
		lista= new ArrayList<Producto>();
		
		
		lista.add(Producto.builder()
				.id(0)
				.nombre("Pipas")
				.categoria("Alimentación")
				.precioU(23.5)
				.fechaAlta(LocalDate.of(2023, 4, 11))
				.build());
		
		lista.add(Producto.builder()
				.id(1)
				.nombre("Uvas")
				.categoria("Alimentación")
				.precioU(4)
				.fechaAlta(LocalDate.of(2023, 12, 1))
				.build());
		
		lista.add(Producto.builder()
				.id(2)
				.nombre("Consola")
				.categoria("Entretenimiento")
				.precioU(60.4)
				.fechaAlta(LocalDate.of(2023, 10, 6))
				.build());
		
		lista.add(Producto.builder()
				.id(3)
				.nombre("Camisas Lisas")
				.categoria("Ropa")
				.precioU(142.4)
				.fechaAlta(LocalDate.of(2023, 2, 3))
				.build());
	}
	
	public List<Producto> findAll(){
		return Collections.unmodifiableList(lista);
	}

}
