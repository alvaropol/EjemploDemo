package com.salesianostriana.dam.demoproduct;

import java.time.LocalDate;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
@AllArgsConstructor
public class Producto {
	
	private int id;
	private String nombre,categoria;
	private double precioU;
	private LocalDate fechaAlta;

}
