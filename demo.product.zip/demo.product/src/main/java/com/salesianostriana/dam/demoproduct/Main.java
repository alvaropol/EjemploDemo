package com.salesianostriana.dam.demoproduct;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;


@Component
public class Main {

	
	double precio1, precio2;
	Scanner sc= new Scanner(System.in);
	@Autowired
	private  ServicioProductos servicioProductos;
	
	
	@PostConstruct
	public void ejecutar() {
		
		System.out.println("Diga el precio más bajo del rango de precio que quieras buscar:");
		precio1=Double.parseDouble(sc.nextLine());
		System.out.println("Diga el precio más alto del rango de precio que quieras buscar:");
		precio2=Double.parseDouble(sc.nextLine());
		
		System.out.println("Productos entre "+precio1+"€ y "+precio2+"€");
		servicioProductos.buscarEntrePrecios(precio1, precio2).forEach(x -> System.out.println(x));
	}

}
