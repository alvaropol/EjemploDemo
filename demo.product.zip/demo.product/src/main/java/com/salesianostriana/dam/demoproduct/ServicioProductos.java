package com.salesianostriana.dam.demoproduct;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServicioProductos {
	
	@Autowired
	private AlmacenProductos almacenProductos;
	
	public List<Producto> buscarEntrePrecios(double precio1, double precio2){
		List<Producto> result = new ArrayList<Producto>();
		
		result = almacenProductos.findAll()
				.stream()
				.filter(x -> x.getPrecioU()>=precio1 && x.getPrecioU() <=precio2)
				.toList();
		
		return result;
	}

}
